## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-30
## Ask03_Lab08 DBSP

load ECG;
x=EKG1;
%x=EKG2;
fs=250;

n=1:length(x);
Ts=1/fs;
p=10*cos(2*pi*50*n*Ts);
x=x+p';

%Claculating ECG Spectrum
y=fft(x);
K=length(y);
k=1:K;
frequency=k*fs/K;
magnitude=abs(y);

%Plotting ECG Spectrum
figure;
subplot(311); plot(frequency,magnitude);
xlabel('Frequency');
ylabel('Magnitude');

cutoffHz=0.5;
cutoff=2*cutoffHz/fs;
f=[0 cutoff cutoff 1];
m=[0 0 1 1];


%Remove baseline wander
sx=smooth(x,150);
xx = x-sx;  


cutoff1Hz=45;
cutoff1=2*cutoff1Hz/fs;
cutoff2Hz=55;
cutoff2=2*cutoff2Hz/fs;

f = [0 cutoff1 cutoff1 cutoff2 cutoff2 1];
m = [1 1 0 0 1 1];
[b,a] = yulewalk(8,f,m);  
[H,w] = freqz(b,a,128); 
output = filter(b,a,xx);


%Frequency Response
H=fft(h);
K=length(H);
k=1:K;
frequency=k*fs/K;
magnitude=abs(H);
subplot(312);
plot(frequency,magnitude);
xlabel('Freq');
ylabel('Magn');

Y=fft(output);
K=length(Y);
k=1:K;
frequency=k*fs/K;
magnitude=abs(Y);
subplot(313);
plot(frequency,magnitude);
xlabel('Freq');
ylabel('Magn');


%Plot
xmax=3000;
ymax=500;
figure;
subplot(211); plot(x);
axis([0 xmax -ymax ymax]);
subplot(212); plot(output);
axis([0 xmax -ymax ymax]);
