## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-12-07
## Ask01_Lab08 DBSP

load ECG;
x=EKG1;
fs=250;

n=1:length(x);
Ts=1/fs;
p=10*cos(2*pi*50*n*Ts);
x=x+p';

%Claculating ECG Spectrum
y=fft(x);
K=length(y);
k=1:K;
frequency=k*fs/K;
magnitude=abs(y);

%Plotting ECG Spectrum
figure;
subplot(211); plot(frequency,magnitude);
xlabel('Frequency');
ylabel('Magnitude');

%High Pass Filter (diwxnei thorybo anapnohs)
cutoffHz=0.5;
cutoffIndex=int16(cutoffHz*K/fs);
y(1:cutoffIndex)=0;
y(K-cutoffIndex)=0;

%Band-Rejection Filter for Noise
cutoff1Hz=49;
cutoff1Index=int16(cutoff1Hz*K/fs);
cutoff2Hz=51;
cutoff2Index=int16(cutoff2Hz*K/fs);
y(cutoff1Index:cutoff2Index)=0;     
y(K-cutoff2Index:K-cutoff1Index)=0; 

magnitude=abs(y);
subplot(212); plot(frequency,magnitude);
xlabel('Frequency');
ylabel('Magnitude');

%Processed signal
iy=ifft(y);

%Plot
xmax=3000;
ymax=500;
figure;
subplot(211); plot(x);
axis([0 xmax -ymax ymax]);
subplot(212); plot(real(iy));
axis([0 xmax -ymax ymax]);

##a
##Den prostithetai o thoruvos apo thn tash tou reumatos p sto shma mou 

##b 
##isiwnei otan diwxnw th xamhlh syxnothta(high pass filter 0.5) sto EKG2 & efarmozw ifft

##c 
##

##d 
##me fir & iir filters