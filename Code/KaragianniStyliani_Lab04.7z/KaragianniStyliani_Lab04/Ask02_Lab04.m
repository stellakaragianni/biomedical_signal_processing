## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-02
## Ask02_Lab04 DBSP

##Sampling Shenanigans
fs=200;
Ts=1/fs;
tmin=0;
tmax=0.1;
t=tmin:Ts:tmax;

##complexExpFun Shenanigans
A=10;
f=100;
phi=pi/4;
x=A*exp(j*(2*f*pi*t+phi));

##Plotting
figure;
subplot(221);
plot(t,real(x),'o-');
title('Real');

subplot(222);
plot(t,imag(x),'o-');
title('Imag');

subplot(223);
plot(t,abs(x),'o-');
title('Metro');

subplot(224);
plot(t,angle(x),'o-');
title('Phasi');