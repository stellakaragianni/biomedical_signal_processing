## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-02
## Ask04_Lab04 DBSP MyChirp

f1=220;
f2=2320;
T2=3;

fs=10*f2;
t=0:1/fs:0.5;
x=[];
temp=0;
for i=1:length(t)
    x=[x temp];
    temp=temp+0.00005*f1;
end
y=sin(2*pi*t.*x);
plot(y);
##sound(y,fs);