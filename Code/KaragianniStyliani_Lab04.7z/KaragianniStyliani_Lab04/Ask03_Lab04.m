## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-02
## Ask03_Lab04 DBSP

##Sampling Shenanigans
fs=900;
t=0:1/fs:0.2;

##complexExpFun Shenanigans
x=AMSignal(660,12,t);
y=AMSignal(330,6,t);
z=AMSignal(990,15,t);
w=[cos(2*pi*(660)*t).*cos((2*pi*(12)*t)+ pi/2)];

##Plotting
figure;
subplot(411);
plot(t,x,'-');
title('1st attempt');

subplot(412);
plot(t,y,'-');
title('2nd attempt');

subplot(413);
plot(t,z,'-');
title('3rd attempt');

subplot(414);
plot(t,w,'-');
title('4rth attempt');

##Conclusion:
##Oso ayxanw tis f toso platainei to shma,enw oso tis meiwnw sympeiknwnetai
##Epishs, gia na kanw to sin cos prepei na balw fash pi/2
