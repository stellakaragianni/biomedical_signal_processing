## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-02

function [x] = AMSignal (f1, f2, t)
    x=cos(2*pi*(f1)*t).*sin(2*pi*(f2)*t);
endfunction
