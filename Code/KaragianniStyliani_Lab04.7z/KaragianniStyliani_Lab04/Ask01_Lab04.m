## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-02
## Ask01_Lab04 DBSP
fs=44100;
t=0:1/fs:1;

##a
x1=sin(2*pi*440*t);
subplot(311);
plot(t,x1);
axis[(0 0.05 -1.2 1.2)];
xlabel('Time(sec)');
ylabel('Amplitude');
title('Sin');

x2=square(2*pi*440*t);
subplot(312);
plot(t,x2);
axis[(0 0.05 -1.2 1.2)];
xlabel('Time(sec)');
ylabel('Amplitude');
title('Square');

x3=sawtooth(2*pi*440*t);
subplot(313);
plot(t,x3);
axis[(0 0.05 -1.2 1.2)];
xlabel('Time(sec)');
ylabel('Amplitude');
title('Sawtooth');


##b
x=[x1 x2 x3];

##c
t=1/fs*(0:length(x)-1;
plot(t,x);
sound(x,fs);



