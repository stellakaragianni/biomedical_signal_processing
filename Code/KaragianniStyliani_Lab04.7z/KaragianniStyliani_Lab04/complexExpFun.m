## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-02

function [x] = complexExpFun (A, f, t, phi)
      x=A*exp(j*(2*f*pi*t+phi));
endfunction
