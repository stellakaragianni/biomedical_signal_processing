function [exodos]= mymin(x)
	if size(x)== 1
		disp('OK!');
		disp(min(x));
	else
		disp('ERROR!');
	end
end	

%klhsh mesa se programma : elaxisto = mymin(x);