myStr='test';
for a 1:1:10
	num= int2str(a);
	newStr= [myStr num];
	disp(newStr);
end	