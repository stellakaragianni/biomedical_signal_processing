## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-12-14
## Ask02_Lab09 DBSP

load ECG;
x=EKG1;
fs=250;

%QRS detection
figure;
hold on;
h=[-1 1];
d=conv(x,h);
maxima=[];
for z=1:length(x)
	if ( (d(z)<=0) & (d(z+1)>0) )
	   maxima(z)=x(z);
	else
	  minima(z)=x(z);
	end
end
threshold=270;
maxima=(maxima>threshold).*maxima;
plot(maxima,'ro');
plot(minima,'go');
plot(x);
axis([0 3000 -350 350]);
hold off;