## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-12-21
## Ask01_Lab10 DBSP
clear all;
load EEG.mat;

N=4;
fs=200;
time=0:1/fs:(length(eeg)-1)*1/fs;

%Delta
Wn_d=2*4/fs;
[b,a]=butter(N,Wn_d)
delta=filter(b,a,eeg);

%Verify in frequency domain
in_vect=delta;
[freq,amp,phaz]=fftFun(in_vect,fs);
figure(1)
title('Frequency Content');
hold on
subplot(221), plot(freq,amp)
xlabel('Freq(Hz)')
ylabel('Ampl')
title('delta waves')

%Theta
W1=2*4/fs;
W2=2*8/fs;
Wn_t=[W1 W2];
[c,d]=butter(N,Wn_t)
theta=filter(c,d,eeg);

%Verify in frequency domain
in_vect=theta;
[freq,amp,phaz]=fftFun(in_vect,fs);
figure(1)
subplot(222), plot(freq,amp)
xlabel('Freq(Hz)')
ylabel('Ampl')
title('theta waves')


%Alpha
W3=2*8/fs;
W4=2*13/fs;
Wn_a=[W3 W4];
[e,f]=butter(N,Wn_a)
alpha=filter(e,f,eeg);

%Verify in frequency domain
in_vect=alpha;
[freq,amp,phaz]=fftFun(in_vect,fs);
subplot(223), plot(freq,amp)
xlabel('Freq(Hz)')
ylabel('Ampl')
title('alpha waves')


%Beta
W5=2*13/fs;
W6=2*40/fs;
Wn_b=[W5 W6];
[g,h]=butter(N,Wn_b)
beta=filter(g,h,eeg);

%Verify in frequency domain
in_vect=beta;
[freq,amp,phaz]=fftFun(in_vect,fs);
subplot(224), plot(freq,amp)
xlabel('Freq(Hz)')
ylabel('Ampl')
title('beta waves')
hold off;

%Frequency of raw signal
in_vect=eeg;
[freq,amp,phaz]=fftFun(in_vect,fs);
figure
plot(freq,amp)
xlabel('Freq(Hz)')
ylabel('Ampl')
title('raw eeg signal')

%Figures
figure
hold on
title('EEG Wave Patterns')
subplot(511), plot(time,eeg)
xlabel('time')
ylabel('ampl')
title('raw eeg signal')
subplot(512), plot(time,delta)
xlabel('time')
ylabel('ampl')
title('delta waves')
subplot(513), plot(time,theta)
xlabel('time')
ylabel('ampl')
title('theta waves')
subplot(514), plot(time,alpha)
xlabel('time')
ylabel('ampl')
title('alpha waves')
subplot(515), plot(time,beta)
xlabel('time')
ylabel('ampl')
title('beta waves')
hold off

