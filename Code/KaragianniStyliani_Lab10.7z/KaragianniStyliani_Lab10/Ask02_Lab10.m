## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-12-21
## Ask02_Lab10 DBSP

clear all;
f=10;
fs = 100;
Ts=1/fs;
t=0:Ts:1;
l=length(t);
N=100;
x = 2*cos(2*pi*f*t);
n=randn(N,l);
xn=[];
for (i=1:N)
	xn(i,:)=x+n(i,:);
end
plot(t,xn(2,:));
z=mean(xn);
figure;
plot(t,z); 
