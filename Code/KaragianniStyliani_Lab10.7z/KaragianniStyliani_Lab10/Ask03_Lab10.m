## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-12-21
## Ask03_Lab10 DBSP

clear all;

fs = 250;
Ts=1/fs;
t=0:Ts:1;
l=length(t);
N=100;
x =load(EEG);
n=randn(N,l);
xn=[];
for (i=1:N)
	xn(i,:)=x+n(i,:);
end
plot(t,xn(2,:));
z=mean(xn);
figure;
plot(t,z); 