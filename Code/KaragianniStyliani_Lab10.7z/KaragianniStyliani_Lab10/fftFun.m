% A Matlab DSP Example by D.K. Iakovidis
% Calculates the Fourier spectrum of any signal x

function [frequency, magnitude, phase] = fftFun(x, fs)

% Fast Fourier Transform
y = fft(x);

% y is a complex discrete signal with m=length(y) samples
% the samples correspond to 0, fs/m, 2fs/m...
m = length(y);
frequencyAxis = (0:m)*fs/m; 
fftAmplitude = abs(y);
fftPhase = angle(y);

% Construct the right axes
frequency = [-(frequencyAxis(m)-frequencyAxis(m/2:m)) frequencyAxis(1:m/2)];
magnitude = [fftAmplitude(m/2:m) fftAmplitude(1:m/2)];
phase = [fftPhase(m/2:m) fftPhase(1:m/2)];


