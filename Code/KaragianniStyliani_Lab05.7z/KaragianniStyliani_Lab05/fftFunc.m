## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-09
##Calculation of the Fourier Spectrum of a signal x

function [frequency, magnitude, phase] = fftFunc (x, fs)
  y=fft(x);
  m=length(y);
  freqAxis=(0:m)*fs/m;
  fftMagnitude=abs(y);
  fftPhase=angle(y);
  
  frequency= [-(freqAxis(m)-freqAxis(m/2:m)) freqAxis(1:m/2)];
  magnitude= [fftMagnitude(m/2:m) fftMagnitude(1:m/2)];
  phase= [fftPhase((m/2:m) fftPhase(1:m/2)];

endfunction
