## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-09
## Ask03_04_Lab05 DBSP

fs=1000;
Ts=1/fs;
tmin=0;
tmax=0.05;
t=tmin:Ts:tmax;

f1=100;
f2=200;
f3=300;
A=10;
phi=0;

x1=A*cos(2*pi*f1*t+phi);
x2=A*cos(2*pi*f2*t+phi);
x3=A*cos(2*pi*f3*t+phi);
x=x1+x2+x3;

N=length(x);
n=1:N;

figure;
subplot(311);
plot(t,x);
title('Original');

figure;
subplot(312);
plot(n,x);
title('Discrete(samples)');
axis([0 50 -5*A 5*A]);

reconstructed=[];
for n=1:N
  reconstructed(n)=sum(x(n).*sinc(t(n)-n*Ts));   ##sinc
  ##reconstructed(n)=sum(x(n).*myPulseFun(t(n)-n*Ts));   ##palmos
endfor

figure;
subplot(313);
plot(t,reconstructed);
title('Reconstructed signal');

figure;
[f,a,p]=fftFunc(x,fs);
subplot(211);
plot(f,a);
axis([-100 100 0 6000]);
title('Spectrum of the original');
[f,a,p]=fftFunc(reconstructed,fs);
subplot(212);
plot(f,a);
axis([-100 100 0 6000]);
title('Spectrum of the reconstructed');

##Conclusion:

##Sinc:den yparxei diafora metaxy twn 2 shmatwn oute sthn apeikonish oute sto fasma
##(logiko efoson kanw anaparastash sto matlab(pc))

##Pulse:se antithesi me thn sinc,otan kanw xrhsh tou palmou,tote yparxoun diafores
##sthn apeikonish tou analogikou me to pshfiako