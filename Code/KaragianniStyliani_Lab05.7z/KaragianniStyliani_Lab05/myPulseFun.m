## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-26

function [x] = myPulseFun (t,t0,d)  ##d is duration of the pulse
 	starting= t0;
	ending=t0 + d;
	x =(t >= starting) & (t <= ending); 
endfunction