## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-09
## Ask05_Lab05 DBSP

f1=220;
f2=2320;
T2=3;
phi=0;

fs=10*f2;
t=0:1/fs:1;

##chirp
figure;
x= chirp(t,f1,T2,f2);
subplot(211);
plot(t, x);

##Fourier
[freq, mag, phase]=fftFun(x, fs);

subplot(212);
plot(freq,mag);

##Conclusion:

##Epeidh to titivisma den exei statherh syxnothta(h syxnothta exartatai apo ton xrono)
##den mporei na tou ginei fourier transformation (FT mono se statika shmata)
