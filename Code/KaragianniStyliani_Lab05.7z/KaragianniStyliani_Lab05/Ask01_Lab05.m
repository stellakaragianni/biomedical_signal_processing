## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-09
## Ask01_Lab05 DBSP

fs=1000;
Ts=1/fs;
tmin=0;
tmax=0.05;
t=tmin:Ts:tmax;

f1=100;
f2=200;
f3=300;
A=10;
phi=0;

x1=A*cos(2*pi*f1*t+phi);
x2=A*cos(2*pi*f2*t+phi);
x3=A*cos(2*pi*f3*t+phi);
x=x1+x2+x3;

figure;
plot(t,x,'o-');
title('Original');

##a
y=fft(x);
N=length(y);
n=1:N;

figure;
subplot(211); 
plot(n,abs(y));
xlabel('Samples');
ylabel('Mag');

subplot(212); 
plot(n,angle(y));
xlabel('Samples');
ylabel('Phase');



##b
[frequency,magnitude,phase] = fftfun (x, fs);

figure;
subplot(211); 
plot(frequency,magnitude);
xlabel('Freq');
ylabel('Mag');

subplot(212); 
plot(frequency,phase);
xlabel('Freq');
ylabel('Phase');


##c
y=fft(x);
x=ifft(y);

figure;
plot(t,real(x));
title('Reconstructed');
