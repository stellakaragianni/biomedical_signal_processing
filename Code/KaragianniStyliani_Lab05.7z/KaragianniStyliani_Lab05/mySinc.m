t=-100:0.001:100;
y=sin(t)./t;
plot(t,y);