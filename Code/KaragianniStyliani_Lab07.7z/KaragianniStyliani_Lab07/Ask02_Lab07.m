## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-23
## Ask02_Lab07 DBSP


fs=1000;
Ts=1/fs;
tmin=0;
tmax=0.05;
t=tmin:Ts:tmax;

a1=[1 -1.25];
b1=[2 2];
##a2=[1 -0.8];
##b2=[2 2];


%Apokrish Syxnothtas
w=-pi:(pi/100):pi;
H=freqz(b1,a1,w);
%H=freqz(b2,a2,w);

%Kroustikh Apokrish
h=ifft(H);
##[h,t]=impz(b2,a2);

figure;
subplot(221);
plot(w,h);
title('Impulse Response');
subplot(222);
plot(w,abs(H));
title('Frequency/Magnitude Response');
subplot(223);
plot(w,angle(H));
title('Frequency/Phase Response');
subplot(224);
zplane(b1,a1);
title("Matrix of zeros and poles");
