## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-23
## Ask01_Lab07 DBSP

f=[0 0.6 0.6 1];
m=[1 1 0 0];
[b,a]=yulewalk(8,f,m);
[H,w]=freqz(b,a,128);

hold on;
plot(f,m,'b');
plot(w/pi,abs(H),'r');
xlabel('Normalized Freqeuncy(divided by pi');
ylabel('Magnitude');
title('Comparison of Frequency Response Magnitudes');

%Symperasmata:

%a
%Me thn ylopoihsh me fir2 h ptwsh ths kampylhs einai pio omalh sta breakpoints
%Antitheta me thn yule-walk fainetai kai h merikh apotomh aykshsh tou platous prwtou meiwthei
%To apotelesma sth deyterh einai pio realistiko

%b
%Oso ayxanw thn timh ths taxhs tou filtrou (dhladh pairnw perissotera shmeia)
%H kampylh toy filtroy moiazei olo kai perissotero me to ideal
%Antitheta sumbainei otan meiwnw thn taksh