## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-20

function [x] = unitStepFun (t, t0)
x=(t>=t0);
endfunction
