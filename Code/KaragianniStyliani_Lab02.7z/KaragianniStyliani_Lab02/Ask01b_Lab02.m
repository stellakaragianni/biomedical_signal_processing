## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-20

##Signal Shifting: Delay & Advance

t=[-100:100];
figure;

subplot(3,1,1); ##Array 3x1, first seat
x=unitStepFun(t,0);  ##Function
plot(t,x,'o-');   ##Plot Step Function
title('Original');
xlabel('Time');
ylabel('Vhmatikh');
grid on;  ##Plegma

subplot(3,1,2); ##Same Array 3x1, second seat
x=unitStepFun(t,0);  ##Function
plot(t,x,'o-');   ##Plot Step Function
title('Delay(Right Shifted)');
xlabel('Time');
ylabel('Vhmatikh');
grid on;  ##Plegma

subplot(3,1,3); ##Same Array 3x1, thrid seat
x=unitStepFun(t,0);  ##Function
plot(t,x,'o-');   ##Plot Step Function
title('Advance(Left Shifted)');
xlabel('Time');
ylabel('Vhmatikh');
grid on;  ##Plegma

