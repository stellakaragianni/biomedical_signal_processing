## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-20

function [x] = pulseFun (t,t0,d)  ##d is duration of the pulse
 	starting= t0;
	ending=t0 + d;
	x =(t >= starting) & (t <= ending); 
endfunction
