## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-20

##Impulse Function
function [x] = impulseFun (t,t0)
  x=(t == t0);  ##if time is 0 then delta is 1
endfunction
