## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-20

##Figure of 3 different sinusoid functions for t,2t and t/2

##Sampling "Shenanigans"
fs = 16;            ##frequency
Ts = 1/fs;          ##period
tmin = 0;           ##time min value
tmax = 10;          ##time max value
t = tmin:Ts:tmax;   ##diasthma

x = sinusoidFun(t,1,1,0);
y1 = sinusoidFun(2*t,1,1,0);
y2 = sinusoidFun(t/2,1,1,0);

##Figure "Shenanigans"
figure;

subplot(3,1,1);
plot(t, x, 'o-');
title('Original');

subplot(3,1,2);
plot(t, y1, 'o-');
title('y1(t)=x(2t)');

subplot(3,1,3);
plot(t, y2, 'o-');
title('y2(t)=x(t/2)');
