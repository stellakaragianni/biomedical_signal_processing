## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-20

function [x] = sinusoidFun (t,A,f,phi)
  x= A*cos(2*pi*f*t + phi);
endfunction
