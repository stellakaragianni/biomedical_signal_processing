## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-20

##Figure of delta and pulse function

t = 0:10;   ##Diasthma Timwn
% a
x = impulseFun(t, 0);
y = impulseFun(t, 2);

figure;   ##First Figure
subplot(2,1,1);
plot(t, x, 'o-');
subplot(2,1,2);
plot(t, y, 'o-');

% b
x = pulseFun(t, 0, 2);
y = pulseFun(t, 2, 2);

figure;   ##Second Figure
subplot(2,1,1);
plot(t, x, 'o-');
subplot(2,1,2);
plot(t, y, 'o-');
