## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-20

function [x] = pulse2Fun (t,t0,d)  ##d is duration of the pulse
  starting = t0;
	ending= t0 + d;
	x = unitStepFun(t,starting) - unitStepFun(t,ending); 
endfunction
