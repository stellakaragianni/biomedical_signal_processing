## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-26
## Script for Ask01_Lab03 DBSP

t=0:0.1:10;

##a
x=rampFun(t,0);
y=rampFun(t,2);

figure;
subplot(2,1,1);
plot(t,x,'o');
title('RampFun');
xlabel('Time');
ylabel('Ramp');
grid on;

subplot(2,1,2);
plot(t,y,'o');
xlabel('Time');
ylabel('Ramp');
grid on;

##b
x=expFun(2,t,0);
y=expFun(2,t,5);

figure;
subplot(2,1,1);
plot(t,x,'o');
title('ExpFunction');
xlabel('Time');
ylabel('Exp');
grid on;

subplot(2,1,2);
plot(t,y,'o');
xlabel('Time');
ylabel('Exp');
grid on;

##c
x=sinusoid(3,t,0,0,0.1);
y=sinusoid(3,t,2,pi,0.1);

figure;
subplot(2,1,1);
plot(t,x,'o');
title('Sinusoid');
xlabel('Time');
ylabel('Sin');
grid on;

subplot(2,1,2);
plot(t,y,'o');
xlabel('Time');
ylabel('Sin');
grid on;