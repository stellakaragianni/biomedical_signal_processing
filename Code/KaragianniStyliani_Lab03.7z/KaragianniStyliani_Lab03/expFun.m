## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-26

function [x] = expFun (a, t, t0)
x=a.^(t-t0); 
endfunction
