## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-26

function [x] = myUnitStepFun (t, t0)
x=(t>=t0);
endfunction
