## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-26
## Script for Ask02_Lab03 DBSP

t=0:0.05:10;

##a
y1=myUnitStepFun(t,0).*sinusoidFun(t,1,0.1,0);
y2=myUnitStepFun(t,2).*sinusoidFun(t,1,0.1,0);

figure;
subplot(2,1,1);
plot(t,y1,'o');
title('Hmitonoeidhs epi Vhmatikh');
xlabel('Time');
ylabel('x(t)u(t-0)');
grid on;

subplot(2,1,2);
plot(t,y2,'o');
xlabel('Time');
ylabel('x(t)u(t-2)');
grid on;



##b
y1=myPulseFun(t,0,3).*sinusoidFun(t,1,0.1,0);
y2=myPulseFun(t,2,3).*sinusoidFun(t,1,0.1,0);

figure;
subplot(2,1,1);
plot(t,y1,'o');
title('Hmitonoeidhs epi Tetragwniko Palmo');
xlabel('Time');
ylabel('x(t)p(t-0)');
grid on;

subplot(2,1,2);
plot(t,y2,'o');
xlabel('Time');
ylabel('x(t)p(t-2)');
grid on;




##c

##Yparxei provlima sto plot edw,oi grafikes vgainoun idies,oi synarthseis den exoun problhma
##isws ftaiei to diasthma timwn tou t h oi syntelestes tou exp
##prospathisa kai me thn expFun alla ginetai poliploko kai den douleuei

y1=exp(t-0).*sinusoidFun(t,1,1,0);
y2=exp(t-2).*sinusoidFun(t,1,1,0);

figure;
subplot(2,1,1);
plot(t,y1,'o');
title('Hmitonoeidhs epi Ekthetikh');
xlabel('Time');
ylabel('x(t)e^(t-0)');
grid on;

subplot(2,1,2);
plot(t,y2,'o');
xlabel('Time');
ylabel('x(t)e^(t-2)');
grid on;