## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-26
## Script for Ask03_Lab03 DBSP

t=0:0.05:10;

noise=noiseFun(1,t);
x1=myPulseFun(t,2,3);
x2=sinusoidFun(t,1,1,0);
y1=x1+noise;
y2=x2+noise;

##a
figure;
subplot(3,1,1);
plot(t,noise,'-');
title('Noise');
grid on;

subplot(3,1,2);
plot(t,x1,'o');
title('Pulse');
grid on;

subplot(3,1,3);
plot(t,y1,'o-');
title('Signal with Noise');
grid on;




##b
figure;
subplot(3,1,1);
plot(t,noise,'-');
title('Noise');
grid on;

subplot(3,1,2);
plot(t,x2,'o');
title('Pulse');
grid on;

subplot(3,1,3);
plot(t,y2,'o-');
title('Signal with Noise');
grid on;