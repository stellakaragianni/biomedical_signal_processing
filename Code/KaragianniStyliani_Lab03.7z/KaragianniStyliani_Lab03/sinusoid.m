## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-26

function [x] = sinusoid (A, t, t0, phi, f)
x=A.*cos(2*pi*f*(t-t0)+phi)
endfunction
