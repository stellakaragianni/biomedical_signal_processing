## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-26

function [x] = noiseFun (A, t)
x=randn(A,length(t));
endfunction
