## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-10-26

function [x] = sinusoidFun (t,A,f,phi)
  x= A*cos(2*pi*f*t + phi);
endfunction
