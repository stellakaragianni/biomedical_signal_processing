## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-16
## Ask02_Lab06 DBSP

f1 = 10;
f2 = 20;
f3 = 30;
f4=  100;
fs = 500;
Ts = 1/fs;
tmin=0;
tmax=0.5;
t=tmin:Ts:tmax;

A=10;
phi=0;


x1 = A*cos(2*pi*f1*t+phi);
x2 = A*cos(2*pi*f2*t+phi);
x3 = A*cos(2*pi*f3*t+phi);
x4 = A*cos(2*pi*f4*t+phi);
x = x1 + x2 +x3 +x4;

figure;
subplot(511);
plot(t,x);
title('Signal');

[frequency,magnitude,phase]=fftFun(x,fs);
subplot(512);
plot(frequency,magnitude);
title('FFT in Frequency domain');


w=2*frequency/fs;
l=length(w);
w=w(l/2:l);
magnitude=magnitude(l/2:l);
subplot(513);
plot(w,magnitude);
title('FFT in Digital Frequency domain');



% Filtering 1&2
fcut = 50;
wcut = 2*fcut/fs; %prepei na ikanopoieitai Nyquist

% LowPassFilter
m = [1 1 0 0];
w = [0 wcut wcut 1];

% HighPassFilter
% m = [0 0 1 1];
% w = [0 wcut wcut 1];

##% Filtering 3
##fcut1 = 15;
##fcut2 = 35;
##wcut1 = 2*fcut1/fs; % digital frequency
##wcut2 = 2*fcut2/fs; % digital frequency

##% BRF (band reject filter)
##m = [1 1 0 0 1 1]; %filtro (poies perioxes thelw na perasoun=1 & poies thelw na kopoun=0)
##w = [0 wcut1 wcut1 wcut2 wcut2 1]; 


h = fir2(30, w, m); %syntelestes tou filtered signal
[H,omega] = freqz(h,1,128); %zeygh apokrishs syxnothtas me digital frequency

subplot(514);
plot(h,x);

y = conv(h,x); %apply filter


%PLOT OF FILTERED SIGNAL
[newf,newm,newp]= fftFun(y,fs);
subplot(515);
plot(newf,newm);
title('Filtered signal');

##Disclaimer: gia kapoio logo den anagnwrizei thn conv ws function
##gia auto den mporousa na dw to filtered signal
