## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-16

function [x] = noiseSignalFun(t, A)
  x = A*randn(1,length(t)); 

