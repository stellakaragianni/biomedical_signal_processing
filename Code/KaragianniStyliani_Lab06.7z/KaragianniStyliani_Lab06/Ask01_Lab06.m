## Copyright (C) 2020 Stella
## Author: Stella Karagianni
## Created: 2020-11-16
## Ask01_Lab06 DBSP
fs=100;
Ts=1/fs;
t=1:Ts:100;

f=10;
x1=sinusoidFun(t,10,f,0);
x2=noiseSignalFun(t,5);
x3=x1+x2;

%Noise signal
subplot(511);
plot(x3);
grid on;
title('Noisy Signal');
%sound(x3);

%Spectrum of the noise-signal
[fre,mag,pha]=fftFun(x3,fs);
subplot(512);
plot(fre,mag);
grid on;
title('Noisy signal Spectrum');
%axis();

%FIR filter(moving average)
%firFilter=[1/4 1/4 1/4 1/4];
%firFilter=[1/10 1/10 1/10 1/10 1/10 1/10 1/10 1/10 1/10 1/10];
firFilter=[1/8 1/8 1/8 1/8 1/8 1/8 1/8 1/8];
x4=conv(firFilter,x3);
subplot(513);
plot(x4);
grid on;
title('Filtered signal');
%sound(x4);

%Frequency Response of the Filtered
w=-pi:(pi/100):pi;
frere=freqz(firFilter,1,w);
subplot(514);
plot(w,frere);
grid on;
title('Frequency Response of Filter');
%axis();

%Spectrum of the filtered signal
[fre,mag,pha]=fftFun(x4,fs);
subplot(515);
plot(fre,mag);
grid on;
title('Filtered signal Spectrum');

%Symperasmata:
%Exw episynapsei fwtografies me ta diafora apotelesmata opou parathrountai shmantikes diafores gai to b ypoerwthma

